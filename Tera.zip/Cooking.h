#ifndef COOKING_H
#define COOKING_H

//Prototypes
void mgPies(int);
void creamCal(int);
#endif