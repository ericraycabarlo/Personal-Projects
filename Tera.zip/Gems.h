#ifndef GEMS_H
#define GEMS_H

//Prototypes
void rubies(int, double);
void sapphires(int, double);
void emeralds(int, double);
void diamonds(int, double);

#endif