#include "SilverTalents.cpp"

//Menu for Silver Talent conversions
int silverTalentMenu()
{
	int userChoiceA;
	int userChoiceB;
	bool menuA = true;
	
	const double artisanRefiningKitCost = 1.07;
	
	menuA = true;
	while (menuA == true) {
		
		cout << "\n\n--------------------Processing Menu--------------------" << endl;
		cout << "What are you making?" << endl;
		cout << "\t1. Silver Sigloes" << endl;
		cout << "\t2. Silver Plates" << endl;
		cout << "\t3. Return to Metal Crafting" << endl << endl;
		cout << "Choice: ";
		cin >> userChoiceA;
	
		switch(userChoiceA)
		{
			case 1:	cout << "\nHow many silver talents do you have?";
					cout << "\nNumber of Silver Talents: ";
					cin >> userChoiceB;
					silverSigloes(userChoiceB, artisanRefiningKitCost);
					break;
					
			case 2:	cout << "\nHow many silver sigloes do you have?";
					cout << "\nNumber of Silver Sigloes: ";
					cin >> userChoiceB;
					silverPlates(userChoiceB, artisanRefiningKitCost);
					break;
			
			case 3: menuA = false;
					break;
					
			default: cout << "\n\nEnter a valid number!!!" << endl;
					
		}
	}
}