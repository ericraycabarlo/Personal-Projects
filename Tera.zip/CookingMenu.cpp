#include "Cooking.cpp"

//Menu for Alchemy
int cookingMenu()
{
	int userChoiceA;
	int userChoiceB;
	bool menuA = true;
	
	menuA = true;
	while (menuA == true) {
		
		cout << "\n\n--------------------Cooking Menu--------------------" << endl;
		cout << "What are you making?" << endl;
		cout << "\t1. Moongourd Pies" << endl;
		cout << "\t2. Creams" << endl;
		cout << "\t3. Return to Main Menu" << endl << endl;
		cout << "Choice: ";
		cin >> userChoiceA;
	
		switch(userChoiceA)
		{			
			case 1:	cout << "\nHow many pies are you making?" << endl << "MAKE SURE TO ENTER AN EVEN NUMBER!!!";	//IN PROGRESS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
					cout << "\nNumber of Pies: ";
					cin >> userChoiceB;
					mgPies(userChoiceB);
					break;
			
			case 2:	cout << "\nHow many creams are you making? ";
					cin >> userChoiceB;
					creamCal(userChoiceB);
					break;
			
			case 3: menuA = false;
					break;
					
			default: cout << "\n\nEnter a valid number!!!" << endl;
					
		}
	}
}