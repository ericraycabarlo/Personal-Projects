#include "SilverTalents.h"

void silverSigloes(int numSilverTalents, double kitCost)
{
	const int numKits = 60;
	const int productionPoints = 20;
	
	int totalNumSigloes = 3 * (numSilverTalents / 5);
	int totalNumArtisanRefiningKits = totalNumSigloes * numKits;
	int productionPointCost  = totalNumSigloes * productionPoints;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	cout << "\n\tWith " << numSilverTalents << " silver talents, you can make" << endl;
	cout << "\t" << totalNumSigloes << " silver sigloes(s)" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\tCraftingKits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl << endl;
	
	cout << "\t\tProduction Point Cost per craft:\t" << productionPoints << " points" << endl;
	cout << "\t\tTotal Production Point Cost:\t\t" << productionPointCost << " points" << endl;
}

void silverPlates(int numSilverSigloes, double kitCost)
{
	const int numKits = 240;
	const int productionPoints = 80;
	
	int totalNumPlates = 3 * (numSilverSigloes / 5);
	int totalNumArtisanRefiningKits = totalNumPlates * numKits;
	int productionPointCost  = totalNumPlates * productionPoints;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	cout << "\n\tWith " << numSilverSigloes << " silver sigloes, you can make" << endl;
	cout << "\t" << totalNumPlates << " silver plate(s)" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\tCrafting Kits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl << endl;
	
	cout << "\t\tProduction Point Cost per craft:\t" << productionPoints << " points" << endl;
	cout << "\t\tTotal Production Point Cost:\t\t" << productionPointCost << " points" << endl;
}