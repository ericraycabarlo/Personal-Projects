#ifndef GOLD_H
#define GOLD_H

void goldDarics(int, double);
void goldPlates(int, double);

#endif