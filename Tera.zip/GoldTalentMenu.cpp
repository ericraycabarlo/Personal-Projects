#include "GoldTalents.cpp"

//Menu for Gold Talent conversions
int goldTalentMenu()
{
	int userChoiceA;
	int userChoiceB;
	bool menuA = true;
	
	const double artisanRefiningKitCost = 1.07;
	
	menuA = true;
	while (menuA == true) {
		
		cout << "\n\n--------------------Smelting Menu--------------------" << endl;
		cout << "What are you making?" << endl;
		cout << "\t1. Gold Darics" << endl;
		cout << "\t2. Gold Plates" << endl;
		cout << "\t3. Return to Metal Crafting" << endl << endl;
		cout << "Choice: ";
		cin >> userChoiceA;
	
		switch(userChoiceA)
		{
			case 1:	cout << "\nHow many gold talents do you have?";
					cout << "\nNumber of Gold Talents: ";
					cin >> userChoiceB;
					goldDarics(userChoiceB, artisanRefiningKitCost);
					break;
					
			case 2:	cout << "\nHow many gold darics do you have?";
					cout << "\nNumber of Gold Darics: ";
					cin >> userChoiceB;
					goldPlates(userChoiceB, artisanRefiningKitCost);
					break;
			
			case 3: menuA = false;
					break;
					
			default: cout << "\n\nEnter a valid number!!!" << endl;
					
		}
	}
}