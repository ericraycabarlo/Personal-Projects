#ifndef SILVERTALENTS_H
#define SILVERTALENTS_H

void silverSigloes(int, double);
void silverPlates(int, double);

#endif