#include "Gems.h"

void rubies(int numRubies, double kitCost)
{	
	const int numKits = 110;
	const int productionPointCost = 5;
	
	int totalNumArtisanRefiningKits = numRubies * numKits;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	int totalProductionPointCost = numRubies * productionPointCost;
	
	cout << "\n----------------------------------------------------" << endl;
	cout << "\n\tTo make " << numRubies << " ruby/rubies" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	
	cout << "\tCrafting Kits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl;
	
	cout << "\n\t\tProduction Point Cost per craft:\t" << productionPointCost << " points" << endl;
	cout << "\t\tProduction Point Cost:\t\t\t" << totalProductionPointCost << " points" << endl;
}

void sapphires(int numRubies, double kitCost)
{
	
	const int numKits = 20;
	const int productionPointCost = 20;
	
	int totalNumSapphires = numRubies / 2;
	int totalNumArtisanRefiningKits = totalNumSapphires * numKits;
	int totalProductionPointCost = totalNumSapphires * productionPointCost;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	cout << "\n----------------------------------------------------" << endl;
	cout << "\n\tWith " << numRubies << " rubies, you can make" << endl;
	cout << "\t" << totalNumSapphires << " sapphire(s)" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\tCrafting Kits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl << endl;
	
	cout << "\t\tProduction Point Cost per craft:\t" << productionPointCost << " points" << endl;
	cout << "\t\tProduction Point Cost:\t\t\t" << totalProductionPointCost << " points" << endl;
}

void emeralds(int numSappires, double kitCost)
{
	
	const int numKits = 100;
	const int productionPointCost = 85;
	
	int totalNumEmeralds = numSappires / 5;
	int totalNumArtisanRefiningKits = totalNumEmeralds * numKits;
	int totalProductionPointCost = totalNumEmeralds * productionPointCost;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	cout << "\n----------------------------------------------------" << endl;
	cout << "\n\tWith " << numSappires << " sapphires, you can make" << endl;
	cout << "\t" << totalNumEmeralds << " emerald(s)" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\tCrafting Kits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl << endl;
	
	cout << "\t\tProduction Point Cost per craft:\t" << productionPointCost << " points" << endl;
	cout << "\t\tProduction Point Cost:\t\t\t" << totalProductionPointCost << " points" << endl;
}

void diamonds(int numEmeralds, double kitCost)
{
	
	const int numKits = 1000;
	const int productionPointCost = 500;
	
	int totalNumDiamonds = numEmeralds / 10;
	int totalNumArtisanRefiningKits = totalNumDiamonds * numKits;
	int totalProductionPointCost = totalNumDiamonds * productionPointCost;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	cout << "\n----------------------------------------------------" << endl;
	cout << "\n\tWith " << numEmeralds << " emeralds, you can make" << endl;
	cout << "\t" << totalNumDiamonds << " diamond(s)" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\tCrafting Kits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl << endl;
	
	cout << "\t\tProduction Point Cost per craft:\t" << productionPointCost << " points" << endl;
	cout << "\t\tProduction Point Cost:\t\t\t" << totalProductionPointCost << " points" << endl;
}