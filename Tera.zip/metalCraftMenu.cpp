#include "GoldTalentMenu.cpp"
#include "SilverTalentMenu.cpp"

//Menu for crafting gold of silver talents
int metalCraftMenu()
{
	int userChoiceA;
	bool menuA = true;

	
	string metalType;
	
	menuA = true;
	while (menuA == true) {
		
		cout << "\n\n--------------------Metal Crafting--------------------" << endl;
		cout << "What type of metal are you using?" << endl << endl;
		cout << "1.\tGold" << endl;
		cout << "2.\tSilver" << endl;
		cout << "3.\tReturn to Main Menu" << endl << endl;
		cout << "Choice: ";
		cin >> userChoiceA;
		
		switch(userChoiceA)
		{
			case 1:	goldTalentMenu();
					break;
					
			case 2:	silverTalentMenu();
					break;
					
			case 3:	menuA = false;
					break;
			
			default: cout << "Enter a valid number!!!" << endl;
		}
	}
	return 0;
	
}