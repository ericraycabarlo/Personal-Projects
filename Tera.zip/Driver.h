#ifndef DRIVER_H
#define DRIVER_H

#include <iostream>
//#include <stdio.h>
#include <string>
using namespace std;

//#include "metalCraftMenu.cpp"
#include "AlchemiesMenu.cpp"
//#include "CookingMenu.cpp"

#endif