#include "GoldTalents.h"

void goldDarics(int numGoldTalents, double kitCost)
{
	const int numKits = 60;
	const int productionPoints = 20;
	
	int totalNumDarics = 3 * (numGoldTalents / 5);
	int totalNumArtisanRefiningKits = totalNumDarics * numKits;
	int productionPointCost  = totalNumDarics * productionPoints;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	cout << "\n\tWith " << numGoldTalents << " gold talents, you can make" << endl;
	cout << "\t" << totalNumDarics << " gold daric(s)" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\tCrafting Kits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl << endl;
	
	cout << "\t\tProduction Point Cost per craft:\t" << productionPoints << " points" << endl;
	cout << "\t\tTotal Production Point Cost:\t\t" << productionPointCost << " points" << endl;
}

void goldPlates(int numGoldDarics, double kitCost)
{
	const int numKits = 240;
	const int productionPoints = 80;
	
	int totalNumPlates = 3 * (numGoldDarics / 5);
	int totalNumArtisanRefiningKits = totalNumPlates * numKits;
	int productionPointCost  = totalNumPlates * productionPoints;
	
	double costArtisanRefiningKits = totalNumArtisanRefiningKits * kitCost;
	
	cout << "\n\tWith " << numGoldDarics << " gold darics, you can make" << endl;
	cout << "\t" << totalNumPlates << " gold plate(s)" << endl;
	
	cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\tCrafting Kits\t\t" << totalNumArtisanRefiningKits << "\t\t" << costArtisanRefiningKits  << " gold" << endl << endl;
	
	cout << "\t\tProduction Point Cost per craft:\t" << productionPoints << " points" << endl;
	cout << "\t\tTotal Production Point Cost:\t\t" << productionPointCost << " points" << endl;
}