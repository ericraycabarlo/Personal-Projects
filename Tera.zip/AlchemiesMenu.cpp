#include "Gems.cpp"

//Menu for Alchemy
void gemMenu()
{
	int userChoiceA;
	int userChoiceB;
	
	bool menuA = true;
	
	const double artisanRefiningKitCost = 1.07;
	
	menuA = true;
	while (menuA == true) {
		
		cout << "\n\n--------------------Alchemy Menu--------------------" << endl;
		cout << "What are you making?" << endl;
		cout << "\t1. Rubies" << endl;
		cout << "\t2. Sapphires" << endl;
		cout << "\t3. Emeralds" << endl;
		cout << "\t4. Diamonds" << endl;
		cout << "\t5. Return to Main Menu" << endl << endl;
		cout << "Choice: ";
		cin >> userChoiceA;
	
		switch(userChoiceA)
		{
			case 1:	cout << "\nHow many rubies do you need? ";
					cin >> userChoiceB;
					rubies(userChoiceB, artisanRefiningKitCost);
					break;
					
			case 2:	cout << "\nHow many rubies do you have? ";
					cout << "\nNumber of Rubies: ";
					cin >> userChoiceB;
					sapphires(userChoiceB, artisanRefiningKitCost);
					break;
			
			case 3:	cout << "\nHow many sapphires do you have? ";
					cout << "\nNumber of Sapphires: ";
					cin >> userChoiceB;
					emeralds(userChoiceB, artisanRefiningKitCost);
					break;
			
			case 4:	cout << "\nHow many emeralds do you have? ";
					cout << "\nNumber of Emeralds: ";
					cin >> userChoiceB;
					diamonds(userChoiceB, artisanRefiningKitCost);
					break;
			
			case 5: menuA = false;
					break;
					
			default: cout << "\n\nEnter a valid number!!!" << endl;
					
		}
	}
}