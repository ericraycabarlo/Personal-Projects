#include "Cooking.h"

void mgPies(int numPies)	//IN PROGRESS!!!!!!!!!!!!!
{	
	const int productionPointCost = 20;
	
	int totalProductionPointCost = numPies * productionPointCost;	//total cost of of PP
	int numPieProducts = numPies / 2;		//number of expected pies yielded
	
	int numCobseeds = numPieProducts * 10;
	//int baySaltCost = numBaySalt * 2.14;	//need to check price
	
	int numMGPulp = numPieProducts * 20;
	//int purifiedWaterCost = numPurifiedWater * 2.14;	//need to check price
	
	int numWhiteSugars = numPieProducts * 40;
	//int rawEggCost = numRawEggs * 2.14;	//need to check price
	
	int numCream = numPieProducts * 5;
	
	//int totalCost = baySaltCost + purifiedWaterCost + rawEggCost;
	
	cout << "\n\tTo make " << numPies << " Moongourd Pie(s), you need" << endl;
	
	//cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\n\tName" << "\t\t\tQuantity" << endl << endl;
	
	//cout << "\tBay Salts\t\t" << numBaySalt << "\t\t" << baySaltCost  << " gold" << endl;
	cout << "\tCobseeds\t\t" << numCobseeds << endl;
	//cout << "\tPurified Water\t\t" << numPurifiedWater << "\t\t" << purifiedWaterCost  << " gold" << endl;
	cout << "\tMoongourd Pulp\t\t" << numMGPulp << endl;
	//cout << "\tEggs\t\t\t" << numRawEggs << "\t\t" << rawEggCost  << " gold" << endl;
	cout << "\tWhite Sugars\t\t" << numWhiteSugars << endl;
	cout << "\tCream\t\t\t" << numCream << endl;
	
	//cout << "\n\tTotal Cost: " << totalCost << " gold" << endl;
	
	cout << "\n\t\tProduction Point Cost per craft:\t" << productionPointCost << " points" << endl;
	cout << "\t\tProduction Point Cost:\t\t\t" << totalProductionPointCost << " points" << endl;
}

void creamCal(int numProduductNeeded)	//IN PROGRESS!!!!!!!!!!!!!
{
	const int productionPointCost = 5;
	
	int totalProductionPointCost = numProduductNeeded * productionPointCost;	//total cost of of PP
	int result = numProduductNeeded * 2;
	
	cout << "\n\tTo make " << numProduductNeeded << " Cream(s), you need" << endl;
	
	//cout << "\n\tName" << "\t\t\tQuantity" << "\tCost" << endl << endl;
	cout << "\n\tName" << "\t\t\tQuantity" << endl << endl;
	
	//cout << "\tBay Salts\t\t" << numBaySalt << "\t\t" << baySaltCost  << " gold" << endl;
	cout << "\tWhite Sugar\t\t" << result << endl;
	//cout << "\tPurified Water\t\t" << numPurifiedWater << "\t\t" << purifiedWaterCost  << " gold" << endl;
	cout << "\tFresh Milk\t\t" << result << endl;
	
	//cout << "\n\tTotal Cost: " << totalCost << " gold" << endl;
	
	cout << "\n\t\tProduction Point Cost per craft:\t" << productionPointCost << " points" << endl;
	cout << "\t\tProduction Point Cost:\t\t\t" << totalProductionPointCost << " points" << endl;
}